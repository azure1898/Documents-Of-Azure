package com.zhiyou.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.zhiyou.po.User;
import com.zhiyou.service.UserService;

public class TestService {

	@Test
	public void test01() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserService userService = (UserService)ctx.getBean("userService");
		User user = new User();
		user.setUsername("admin");
		user.setPassword("admin");
		
		boolean isExist = userService.isUserExist(user.getUsername(), user.getPassword());
		System.out.println("用户是否存在"+isExist);
	}

}
