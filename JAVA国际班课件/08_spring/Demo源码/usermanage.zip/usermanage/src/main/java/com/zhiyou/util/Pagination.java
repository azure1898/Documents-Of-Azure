package com.zhiyou.util;

/**
 * 分页对象
 *
 */
public class Pagination {
	//当前页码
	private int currentPage;
	
	//每页的记录数
	private int pageSize;
	
	//总页数
	private int totalPage;

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

}
