package com.zhiyou.servlet.user;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zhiyou.base.BaseServlet;
import com.zhiyou.po.User;
import com.zhiyou.util.Pagination;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 从前台页面获取当前页码
		int currentPage = Integer.parseInt(request.getParameter("currentPage")==null?"1":request.getParameter("currentPage"));
		List<User> list = userService.queryUserList();

		// 设置分页对象
		Pagination pagination = new Pagination();
		pagination.setPageSize(pageSize);
		pagination.setCurrentPage(currentPage);
		if (list.size() % pageSize == 0) {
			pagination.setTotalPage(list.size() / pageSize);
		} else {
			pagination.setTotalPage(list.size() / pageSize + 1);
		}

		List<User> userList = userService.queryUserPageList(pagination);
		// 向页面传递查询列表信息
		request.setAttribute("userList", userList);

		// 传递分页信息
		request.setAttribute("pagination", pagination);

		// forward 和 include
		request.getRequestDispatcher("/view/user/user_list.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
