package com.zhiyou.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.zhiyou.dao.UserDao;
import com.zhiyou.po.User;
import com.zhiyou.util.Pagination;

public class UserDaoImpl implements UserDao {
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public boolean isUserExist(String username, String password) {
		// 拼装sql
		String sql = "select * from user where username = '";
		sql += username + "' and password= '" + password + "';";

		// 查询记录
		List list = jdbcTemplate.queryForList(sql);
		if (list != null && list.size() > 0) {// 用户存在
			return true;
		} else {// 用户不存在
			return false;
		}
	}

	@Override
	public int addUser(User user) {
		int i = jdbcTemplate.update("insert into user(username,password,realname,birthday) values (?,?,?,?)",
				user.getUsername(), user.getPassword(), user.getRealname(), user.getBirthday());

		return i;
	}

	@Override
	public int updateUser(User user) {
		int i = jdbcTemplate.update("update user set username = ?, password=?, realname = ?,birthday=? where id =?",
				user.getUsername(), user.getPassword(), user.getRealname(), user.getBirthday(), user.getId());

		return i;
	}

	@Override
	public int deleteUser(int id) {
		int i = jdbcTemplate.update("delete from user where id = ?", id);

		return i;
	}

	@Override
	public List<User> queryUserList() {
		List<User> userList = new ArrayList<User>();
		String sql = "select * from user;";
		RowMapper<User> rowMapper = new BeanPropertyRowMapper<User>(User.class);

		userList = jdbcTemplate.query(sql, rowMapper);

		return userList;
	}

	@Override
	public List<User> queryUserPageList(Pagination pagination) {
		List<User> userList = new ArrayList<User>();
		String sql = "select * from user limit " + 
				((pagination.getCurrentPage() - 1) * pagination.getPageSize()) + ", "
				+ pagination.getPageSize();
		RowMapper<User> rowMapper = new BeanPropertyRowMapper<User>(User.class);

		userList = jdbcTemplate.query(sql, rowMapper);


		return userList;
	}

}
