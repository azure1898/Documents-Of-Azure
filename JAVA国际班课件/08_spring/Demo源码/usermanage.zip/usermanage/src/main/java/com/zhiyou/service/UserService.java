package com.zhiyou.service;

import java.util.List;

import com.zhiyou.po.User;
import com.zhiyou.util.Pagination;

public interface UserService {
	
	public List<User> queryUserList();
	
	/**
	 * 根据用户名、密码判断用户是否存在
	 * @param username
	 * @param password
	 * @return
	 */
	public boolean isUserExist(String username,String password);
	
	/**
	 * 用户添加
	 * 
	 * @param user
	 * @return
	 */
	public int addUser(User user);
	
	/**
	 * 用户修改
	 * 
	 * @param user
	 * @return
	 */
	public int updateUser(User user);
	
	
	/**
	 * 用户删除
	 * 
	 * @param id
	 * @return
	 */
	public int deleteUser(int id);

	/**
	 * 查询用户分页信息
	 * 
	 * @param pagination
	 * @return
	 */
	public List<User> queryUserPageList(Pagination pagination);
}
