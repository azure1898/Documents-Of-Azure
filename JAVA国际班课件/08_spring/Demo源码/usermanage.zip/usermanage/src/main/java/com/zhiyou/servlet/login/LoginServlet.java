package com.zhiyou.servlet.login;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.zhiyou.base.BaseServlet;
import com.zhiyou.po.User;
import com.zhiyou.service.UserService;
import com.zhiyou.util.Pagination;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
    

	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		boolean isExist = userService.isUserExist(username, password);
		System.out.println(isExist);
		if(isExist){// 如果登录成功

			// 从前台页面获取当前页码
			System.out.println(request.getParameter("currentPage"));
			int currentPage = Integer.parseInt(request.getParameter("currentPage")==null?"1":request.getParameter("currentPage"));
			List<User> list = userService.queryUserList();

			// 设置分页对象
			Pagination pagination = new Pagination();
			pagination.setPageSize(pageSize);
			pagination.setCurrentPage(currentPage);
			if (list.size() % pageSize == 0) {
				pagination.setTotalPage(list.size() / pageSize);
			} else {
				pagination.setTotalPage(list.size() / pageSize + 1);
			}

			List<User> userList = userService.queryUserPageList(pagination);
			// 向页面传递查询列表信息
			request.setAttribute("userList", userList);

			// 传递分页信息
			request.setAttribute("pagination", pagination);
			
			request.getRequestDispatcher("/view/user/user_list.jsp").forward(request, response);
		} else {
			//跳转到登陆页
			request.setAttribute("message", "用户名/密码错误");
			request.getRequestDispatcher("login.jsp").forward(request, response);
			//response.sendRedirect("login.jsp");
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
