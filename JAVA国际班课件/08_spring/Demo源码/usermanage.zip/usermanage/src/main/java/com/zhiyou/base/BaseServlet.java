package com.zhiyou.base;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.zhiyou.service.UserService;

public abstract class BaseServlet extends HttpServlet {

	private static final long serialVersionUID = -1898021613450645854L;
	
	protected static final int pageSize = 2;//每页的记录数
	
	@Autowired
    protected UserService userService;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		
		//第一种加载方式，加载spring的applicationContext配置
		//ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		//userService = (UserService)ctx.getBean("userService");
		System.out.println("init方法执行");
		
		//第二种:通过Spring的beans自动装配器加载
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, config.getServletContext());
		
		//第三种：WebApplicationContext
		
	}
}
